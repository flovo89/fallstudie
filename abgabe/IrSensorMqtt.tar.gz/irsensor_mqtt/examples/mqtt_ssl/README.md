# ESPMQTT SSL Sample application

Get iot.eclipse.org Certification 

`openssl s_client -showcerts -connect iot.eclipse.org:8883 </dev/null 2>/dev/null|openssl x509 -outform PEM >iot_eclipse_org.pem`
