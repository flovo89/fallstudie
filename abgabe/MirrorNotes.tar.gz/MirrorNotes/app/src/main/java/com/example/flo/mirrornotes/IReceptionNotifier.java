package com.example.flo.mirrornotes;

public interface IReceptionNotifier {

    public void receptionCallback(String res);
}
